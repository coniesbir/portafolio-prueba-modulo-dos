let saludo = "Gracias por ver mi portafolio"
console.log (saludo)